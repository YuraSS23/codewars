/* This code does not execute properly. Try to figure out why.

Solution*/

function multiply(a, b){
    return a * b;
  }