/* Code as fast as you can! You need to double the integer and return it.

Solution*/

function doubleInteger(i) {
    return i*2;
  }