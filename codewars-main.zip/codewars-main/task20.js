/* Write a function which converts the input string to uppercase.

Solution */

function makeUpperCase(str) {
    return str.toUpperCase();
  }